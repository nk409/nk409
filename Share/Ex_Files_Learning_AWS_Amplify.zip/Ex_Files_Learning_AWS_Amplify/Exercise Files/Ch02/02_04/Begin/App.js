import './App.css';
import { Amplify, Analytics } from 'aws-amplify';
import awsconfig from './aws-exports';
Amplify.configure(awsconfig);

function SendAnalytics() {
  Analytics.record({
	name: 'Account',
        attributes: { tech: 'Amplify', author: 'bear'},
        immediate: true
     });
  Analytics.record({
        name: 'Course',
        attributes: { tech: 'CLI', author: 'bear'},
        immediate: true
     });
}

function App() {
  return (
      <>
      <h1>Hello Amplify</h1>
      <button onClick={SendAnalytics}>Send</button>
      </>
  );
}

export default App;
