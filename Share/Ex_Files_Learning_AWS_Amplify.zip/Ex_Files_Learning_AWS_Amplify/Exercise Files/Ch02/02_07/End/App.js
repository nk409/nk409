import './App.css';
import { Amplify, Analytics } from 'aws-amplify';
import awsconfig from './aws-exports';
import { withAuthenticator } from '@aws-amplify/ui-react';
import '@aws-amplify/ui-react/styles.css';
Amplify.configure(awsconfig);

function SendAnalytics() {
  Analytics.record({
	name: 'Account',
        attributes: { tech: 'Amplify', author: 'bear'},
        immediate: true
     });
  Analytics.record({
        name: 'Course',
        attributes: { tech: 'CLI', author: 'bear'},
        immediate: true
     });
}

function App({ signOut, user }) {
  return (
      <>
      <h1>Hello Amplify</h1>
      <h1>Hello {user.username}</h1>
      <button onClick={signOut}>Sign out</button>
      <button onClick={SendAnalytics}>Send</button>
      </>
  );
}

export default withAuthenticator(App);
