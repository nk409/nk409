import React from 'react';
import Contacts from './components/Contacts';
import './App.css';

function App() {
  return (
    <div className="App">
      <Contacts />
    </div>
  );
}

export default App;
