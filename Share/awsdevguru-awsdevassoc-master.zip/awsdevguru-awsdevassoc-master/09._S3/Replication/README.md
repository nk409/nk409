# AWS Developer Associate - S3
These files are used for the replication demo lesson.

