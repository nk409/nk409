# AWS Developer Associate - VPC

## VPC Creation  
Diagram used for VPC  
![alt text](https://bitbucket.org/awsdevguru/awsdevassoc/raw/c8854569f71c2c8732269939ccd7e0d83a626a9c/06._VPC/images/vpc_creation.png "VPC Diagram")  

