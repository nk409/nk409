## Install Deps
```
npm install 
```

## Configure
Edit config.json to change Access and Secret Key ID  
Change bucket name and file key in app.js  

## Run
```
node app.js
```
