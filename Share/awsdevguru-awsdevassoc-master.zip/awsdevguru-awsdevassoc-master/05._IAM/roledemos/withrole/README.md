NOTE: The EC2 instance this is run on must have a role assocciated that allows S3 Read access.

## Install Deps
```
npm install 
```

## Configure
Change bucket name and file key in app.js.

## Run
```
node app.js
```
