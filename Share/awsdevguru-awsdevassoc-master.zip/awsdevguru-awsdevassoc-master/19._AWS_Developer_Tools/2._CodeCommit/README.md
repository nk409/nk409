# AWS Developer Associate - CodeCommit

## CLI Command Examples

** aws codecommit credential-helper help **
```
CREDENTIAL-HELPER()                                        CREDENTIAL-HELPER()



NAME
       credential-helper -

DESCRIPTION
       Provide  a  SigV4  compatible user name and password for git smart HTTP
       These commands are consumed by git and should not used directly.  Erase
       and  Store  are  no-ops.  Get  is  operation to generate credentials to
       authenticate AWS  CodeCommit.  Run  "aws  codecommit  credential-helper
       help" for details

SYNOPSIS
          aws codecommit credential-helper

OPTIONS
       None

AVAILABLE COMMANDS
       o get



                                                           CREDENTIAL-HELPER()
(END) 

```
