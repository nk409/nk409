#!/bin/sh
aws dynamodb list-tables
