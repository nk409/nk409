#!/bin/sh
aws dynamodb delete-table --table-name Olympics

