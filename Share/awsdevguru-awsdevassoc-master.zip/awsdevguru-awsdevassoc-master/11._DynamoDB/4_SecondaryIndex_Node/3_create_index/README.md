# Create Index
This example creates a global secondary index on an existing table.

## Install Deps
```
npm install
```

## Run
```
node app.js
```

## Output
```
```
