# Python Kinesis Firehose Put Example

## Outputs

**Producer**
```
ubuntu@adgu:~/awsdevassoc/16._Kinesis/1_data_streams$ python producer.py 

> Loading words.json
  Loaded 436 words.

> Sending all words to stream.
  Sending: abroad
  Sending: accouchement
  Sending: advertisement
  Sending: afeard/afeared
  Sending: affright
  Sending: ague
<cut>
```
