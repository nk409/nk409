CREATE OR ALTER DATABASE {{env}}_tasty_bytes;
