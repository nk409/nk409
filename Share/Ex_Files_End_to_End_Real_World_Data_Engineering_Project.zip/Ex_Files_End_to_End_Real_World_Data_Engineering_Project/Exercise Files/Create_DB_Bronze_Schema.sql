create database if not exists pacificretail_db;
create schema if not exists bronze;